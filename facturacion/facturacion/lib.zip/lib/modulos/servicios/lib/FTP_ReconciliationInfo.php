<?php
// <!-- phpDesigner :: Timestamp [11/03/2016 05:58:09 p. m.] -->
/**
 * MultiFacturas.com 2016
 * Author: I.R.G.
 */
class FTP_ReconciliationInfo {

}