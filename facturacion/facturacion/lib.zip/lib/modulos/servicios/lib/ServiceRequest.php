<?php
// <!-- phpDesigner :: Timestamp [11/03/2016 05:59:41 p. m.] -->
/**
 * MultiFacturas.com 2016
 * Author: I.R.G.
 */
interface ServiceRequest
{
    public function getParams();
}