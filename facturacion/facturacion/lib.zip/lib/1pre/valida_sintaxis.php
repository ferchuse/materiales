<?php
function mf_valida_sintaxis($datos)
{
    //valida formato de de los campos campurados
    //$datos= array_map_recursive('cfd_fix_dato_xml', $datos);
    return $datos;
}